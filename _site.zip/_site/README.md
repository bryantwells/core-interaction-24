```
bundle exec jekyll serve
```