// An array of objects representing my collection:
var data = [];