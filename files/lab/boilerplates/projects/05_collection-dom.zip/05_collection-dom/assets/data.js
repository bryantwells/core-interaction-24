var data = [
    {
        make: 'Dodge',
        model: 'Charger',
        year: 2019,
		color: 'red'
    },
    {
        make: 'Honda',
        model: 'Element',
        year: 2008,
		color: 'blue'
    },
    {
        make: 'Ford',
        model: 'Escort',
        year: 2013,
		color: 'yellow'
    },
];