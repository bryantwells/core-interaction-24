// VARIABLES
// --------------------------------

var key = 'e92c3c9cd77dad7b1b1d40b741adca16'; // api key
var zip = 10011;

// ELEMENTS
// --------------------------------
var containerElement = document.querySelector('.Container');
var weatherVaneElement = document.querySelector('.WeatherVane');
var infoElement = document.querySelector('.Info');

// API URL
// --------------------------------

var URL = `https://api.openweathermap.org/data/2.5/weather?zip=${ zip }&appid=${ key }&units=imperial`;

// FETCH
// --------------------------------

fetch(URL)
	.then((response) => {
		return response.json();
	})
	.then((data) => {
		render(data);
	});

// RENDER
// --------------------------------

function render(data) {
	infoElement.innerHTML = `
		<p><b>Zip Code</b> ${ zip }</p>
		<p><b>Temp</b> ${ data.main.temp } k</p>
		<p><b>Wind Direction</b> ${ data.wind.deg } deg</p>
		<p><b>Wind Speed</b> ${ data.wind.speed } m/s</p>
	`;	
	containerElement.style.background = `hsl(${ data.main.temp }, 100%, 50%)`;
	weatherVaneElement.style.transform = `rotate(${ data.wind.deg }deg)`;
	weatherVaneElement.style.animationDuration = `${ data.wind.speed / 5 }s`;
}